package com.example.zachary.restaurantmenu;

/**
 * Created by Zachary on 4/12/2016.
 * Project: RestaurantMenu
 */
public class Constants
{
	public static final String BROADCAST_ACTION = "com.example.android.threadsample.BROADCAST";

	public static final String EXTENDED_DATA_STATUS = "com.example.android.threadsample.STATUS";
}
